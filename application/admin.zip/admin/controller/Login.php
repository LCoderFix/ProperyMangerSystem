<?php


namespace app\admin\controller;

use think\Cache;
use think\Controller;
use think\captcha\Captcha;

class Login extends Controller
{
    public function _initialize()
    {
        if (session('user_id')) {
            $this->redirect('admin/index/index');
        }
    }
    public function index()
    {
        if (request()->isAjax()) {
            $data = input('post.');
            /*if(!captcha_check($data['code'])){
                return $this->error('验证码错误');
            }*/
            $user = db('sys_user')->where('username', $data['username'])->find();
            if ($user) {
                if ($user['status'] == 1 && $user['password'] == md5($data['password'])) {
                    session('username', $user['username']);
                    session('user_id', $user['user_id']);
                    session('role_id', $user['role_id']);
                    db('sys_user')->where('user_id', $user['user_id'])->update(['login_time' => time()]);
                    return $this->success('登录成功!',url('admin/index/index')); //信息正确
                } else {
                    return $this->error('用户名或者密码错误，重新输入!'); //密码错误
                }
            } else {
                return $this->error('用户不存在!'); //用户不存在
            }
        } else {
            return view();
        }
    }

    public function forgetPwd()
    {
        return view('forget_pwd');
    }

}